""" This module loads all the classes from the VTK GenericFiltering
library into its namespace.  This is an optional module."""

from vtkGenericFilteringPython import *
