""" This module loads all the classes from the VTK Graphics library into its
namespace.  This is a required module."""

from vtkGraphicsPython import *
