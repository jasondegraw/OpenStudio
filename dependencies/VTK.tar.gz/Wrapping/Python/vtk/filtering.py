""" This module loads all the classes from the VTK Filtering library into
its namespace.  This is a required module."""

from vtkFilteringPython import *
